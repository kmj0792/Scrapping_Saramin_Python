import requests
from bs4 import BeautifulSoup

URL=f"https://www.saramin.co.kr/zf_user/search/recruit?searchword=network"

def get_last_page():
  result=requests.get(URL)
  soup=BeautifulSoup(result.text, "html.parser")
  pages=soup.find("div",{"class":"pagination"}).find_all('a')
  last_pages = pages[-2].get_text(strip=True)
  return int(last_pages) # text인 마지막 페이지를 정수로 받아오기
  

def extract_job(html):
  title=html.find("h2",{"class" : "job_tit"}).find("a")["title"]
  #deadline=html.find("div",{"class" : "job_date"}).find("span")["class"] 
  company=html.find("strong",{"class" : "corp_name"}).find("a")["title"]  
  location = html.find("div",{"class":"job_condition"}).find("span",{"a" : "href"}) 
  job_id = html['value']
  return{ 
    'title':title, 
    'company':company, 
    'location':location,
    "apply_link" : f"https://www.saramin.co.kr/zf_user/jobs/relay/view?isMypage=no&rec_idx={job_id}"   
  }


def extract_jobs(last_page):
  jobs=[]
  for page in range(last_page):
    print(f"job korea Page: {page+1}")
    result = requests.get(f"{URL}&recruitPage={page+1}")
    soup=BeautifulSoup(result.text, "html.parser")
    results=soup.find_all("div", {"class":"item_recruit"})
    for result in results:
      job=extract_job(result)
      jobs.append(job)
  return jobs

def get_jobs():
    last_page=get_last_page()
    jobs=extract_jobs(last_page) 

    return jobs

