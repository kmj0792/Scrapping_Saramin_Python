from jobkorea import get_jobs as get_SaramIn_jobs

from save import save_to_file



SaramIn_jobs=get_SaramIn_jobs()
#jobs= jobkorea_jobs 
save_to_file(SaramIn_jobs)

